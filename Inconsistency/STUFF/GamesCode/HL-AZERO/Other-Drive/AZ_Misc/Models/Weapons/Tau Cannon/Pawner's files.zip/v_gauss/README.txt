can't save "fidget"
I animated the remaining files.